import * as THREE from 'three';

// Generate pixel-art style textures procedurally
function createCanvas(size: number = 16): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  return { canvas, ctx };
}

function addNoise(ctx: CanvasRenderingContext2D, size: number, baseColor: [number, number, number], variance: number = 20) {
  for (let x = 0; x < size; x++) {
    for (let y = 0; y < size; y++) {
      const r = baseColor[0] + (Math.random() - 0.5) * variance;
      const g = baseColor[1] + (Math.random() - 0.5) * variance;
      const b = baseColor[2] + (Math.random() - 0.5) * variance;
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillRect(x, y, 1, 1);
    }
  }
}

export function createGrassTopTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  addNoise(ctx, 16, [76, 153, 0], 30);
  // Add some darker spots
  for (let i = 0; i < 8; i++) {
    const x = Math.floor(Math.random() * 16);
    const y = Math.floor(Math.random() * 16);
    ctx.fillStyle = `rgb(${50 + Math.random() * 20},${100 + Math.random() * 30},0)`;
    ctx.fillRect(x, y, 1, 1);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createGrassSideTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  // Top 4 rows are green
  for (let x = 0; x < 16; x++) {
    for (let y = 0; y < 4; y++) {
      const g = 120 + Math.random() * 40;
      ctx.fillStyle = `rgb(${40 + Math.random() * 20},${g},0)`;
      ctx.fillRect(x, y, 1, 1);
    }
  }
  // Rest is dirt
  for (let x = 0; x < 16; x++) {
    for (let y = 4; y < 16; y++) {
      const r = 134 + (Math.random() - 0.5) * 30;
      const g = 96 + (Math.random() - 0.5) * 20;
      const b = 67 + (Math.random() - 0.5) * 15;
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillRect(x, y, 1, 1);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createDirtTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  addNoise(ctx, 16, [134, 96, 67], 25);
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createStoneTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  addNoise(ctx, 16, [128, 128, 128], 25);
  // Add some darker cracks
  for (let i = 0; i < 6; i++) {
    const x = Math.floor(Math.random() * 14) + 1;
    const y = Math.floor(Math.random() * 14) + 1;
    ctx.fillStyle = `rgb(${80 + Math.random() * 20},${80 + Math.random() * 20},${80 + Math.random() * 20})`;
    ctx.fillRect(x, y, 2, 1);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createWoodSideTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  for (let x = 0; x < 16; x++) {
    for (let y = 0; y < 16; y++) {
      const stripe = Math.sin(x * 0.8) * 10;
      const r = 140 + stripe + (Math.random() - 0.5) * 15;
      const g = 90 + stripe * 0.7 + (Math.random() - 0.5) * 10;
      const b = 50 + stripe * 0.3 + (Math.random() - 0.5) * 8;
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillRect(x, y, 1, 1);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createWoodTopTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  for (let x = 0; x < 16; x++) {
    for (let y = 0; y < 16; y++) {
      const dx = x - 8;
      const dy = y - 8;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const ring = Math.sin(dist * 1.5) * 10;
      const r = 150 + ring + (Math.random() - 0.5) * 15;
      const g = 110 + ring * 0.7 + (Math.random() - 0.5) * 10;
      const b = 60 + ring * 0.3 + (Math.random() - 0.5) * 8;
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillRect(x, y, 1, 1);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createLeavesTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  for (let x = 0; x < 16; x++) {
    for (let y = 0; y < 16; y++) {
      const dark = Math.random() > 0.5;
      if (dark) {
        ctx.fillStyle = `rgb(${30 + Math.random() * 20},${80 + Math.random() * 30},${10 + Math.random() * 10})`;
      } else {
        ctx.fillStyle = `rgb(${40 + Math.random() * 20},${120 + Math.random() * 40},${20 + Math.random() * 10})`;
      }
      ctx.fillRect(x, y, 1, 1);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createSandTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  addNoise(ctx, 16, [210, 200, 160], 20);
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createWaterTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  addNoise(ctx, 16, [30, 100, 200], 20);
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createCoalTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  addNoise(ctx, 16, [128, 128, 128], 20);
  // Add black coal spots
  for (let i = 0; i < 5; i++) {
    const x = Math.floor(Math.random() * 12) + 2;
    const y = Math.floor(Math.random() * 12) + 2;
    const s = Math.floor(Math.random() * 2) + 2;
    for (let dx = 0; dx < s; dx++) {
      for (let dy = 0; dy < s; dy++) {
        ctx.fillStyle = `rgb(${20 + Math.random() * 20},${20 + Math.random() * 20},${20 + Math.random() * 20})`;
        ctx.fillRect(x + dx, y + dy, 1, 1);
      }
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export function createPlanksTexture(): THREE.Texture {
  const { canvas, ctx } = createCanvas();
  for (let x = 0; x < 16; x++) {
    for (let y = 0; y < 16; y++) {
      const plankY = Math.floor(y / 4);
      const offset = plankY % 2 === 0 ? 0 : 8;
      const plankX = Math.floor((x + offset) / 8);
      const shade = ((plankX + plankY) % 2 === 0) ? 0 : -15;
      const r = 180 + shade + (Math.random() - 0.5) * 12;
      const g = 140 + shade + (Math.random() - 0.5) * 10;
      const b = 80 + shade + (Math.random() - 0.5) * 8;
      // Lines between planks
      if (y % 4 === 0 || (x + offset) % 8 === 0) {
        ctx.fillStyle = `rgb(${r - 30},${g - 25},${b - 15})`;
      } else {
        ctx.fillStyle = `rgb(${r},${g},${b})`;
      }
      ctx.fillRect(x, y, 1, 1);
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  return tex;
}

export type BlockType = 'grass' | 'dirt' | 'stone' | 'wood' | 'leaves' | 'sand' | 'water' | 'coal' | 'planks';

export interface BlockMaterials {
  [key: string]: THREE.Material | THREE.Material[];
}

export function createBlockMaterials(): Record<BlockType, THREE.Material[]> {
  const grassTop = createGrassTopTexture();
  const grassSide = createGrassSideTexture();
  const dirt = createDirtTexture();
  const stone = createStoneTexture();
  const woodSide = createWoodSideTexture();
  const woodTop = createWoodTopTexture();
  const leaves = createLeavesTexture();
  const sand = createSandTexture();
  const water = createWaterTexture();
  const coal = createCoalTexture();
  const planks = createPlanksTexture();

  const makeMat = (tex: THREE.Texture) => new THREE.MeshLambertMaterial({ map: tex });
  const makeTransparentMat = (tex: THREE.Texture) => new THREE.MeshLambertMaterial({ map: tex, transparent: true, opacity: 0.7 });

  // Order: +x, -x, +y, -y, +z, -z
  return {
    grass: [
      makeMat(grassSide), makeMat(grassSide),
      makeMat(grassTop), makeMat(dirt),
      makeMat(grassSide), makeMat(grassSide)
    ],
    dirt: Array(6).fill(null).map(() => makeMat(dirt)),
    stone: Array(6).fill(null).map(() => makeMat(stone)),
    wood: [
      makeMat(woodSide), makeMat(woodSide),
      makeMat(woodTop), makeMat(woodTop),
      makeMat(woodSide), makeMat(woodSide)
    ],
    leaves: Array(6).fill(null).map(() => makeMat(leaves)),
    sand: Array(6).fill(null).map(() => makeMat(sand)),
    water: Array(6).fill(null).map(() => makeTransparentMat(water)),
    coal: Array(6).fill(null).map(() => makeMat(coal)),
    planks: Array(6).fill(null).map(() => makeMat(planks)),
  };
}
