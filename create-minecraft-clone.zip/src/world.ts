import * as THREE from 'three';
import { BlockType } from './textures';

// Noise generator with seeded randomness
class PerlinNoise {
  private perm: number[];

  constructor(seed: number = 42) {
    this.perm = [];
    const p = [];
    for (let i = 0; i < 256; i++) p[i] = i;
    let s = seed;
    for (let i = 255; i > 0; i--) {
      s = (s * 16807 + 0) % 2147483647;
      const j = s % (i + 1);
      [p[i], p[j]] = [p[j], p[i]];
    }
    for (let i = 0; i < 512; i++) this.perm[i] = p[i & 255];
  }

  private fade(t: number): number {
    return t * t * t * (t * (t * 6 - 15) + 10);
  }

  private lerp(a: number, b: number, t: number): number {
    return a + t * (b - a);
  }

  private grad(hash: number, x: number, y: number): number {
    const h = hash & 3;
    const u = h < 2 ? x : y;
    const v = h < 2 ? y : x;
    return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
  }

  noise(x: number, y: number): number {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const X = ((xi % 256) + 256) % 256;
    const Y = ((yi % 256) + 256) % 256;
    const xf = x - xi;
    const yf = y - yi;
    const u = this.fade(xf);
    const v = this.fade(yf);
    const aa = this.perm[this.perm[X] + Y];
    const ab = this.perm[this.perm[X] + Y + 1];
    const ba = this.perm[this.perm[X + 1] + Y];
    const bb = this.perm[this.perm[X + 1] + Y + 1];
    return this.lerp(
      this.lerp(this.grad(aa, xf, yf), this.grad(ba, xf - 1, yf), u),
      this.lerp(this.grad(ab, xf, yf - 1), this.grad(bb, xf - 1, yf - 1), u),
      v
    );
  }

  octaveNoise(x: number, y: number, octaves: number = 4, persistence: number = 0.5): number {
    let total = 0;
    let frequency = 1;
    let amplitude = 1;
    let maxValue = 0;
    for (let i = 0; i < octaves; i++) {
      total += this.noise(x * frequency, y * frequency) * amplitude;
      maxValue += amplitude;
      amplitude *= persistence;
      frequency *= 2;
    }
    return total / maxValue;
  }
}

export const CHUNK_SIZE = 16;
export const WORLD_HEIGHT = 64;
export const WATER_LEVEL = 20;
export const RENDER_DISTANCE = 6; // chunks
export const UNLOAD_DISTANCE = 8; // chunks

// Seeded random for tree placement
function seededRandom(x: number, z: number, seed: number): number {
  let h = (seed * 374761393 + x * 668265263 + z * 2147483647) | 0;
  h = ((h ^ (h >> 13)) * 1274126177) | 0;
  h = h ^ (h >> 16);
  return (h & 0x7fffffff) / 0x7fffffff;
}

export interface ChunkData {
  cx: number;
  cz: number;
  blocks: (BlockType | null)[][][]; // CHUNK_SIZE x WORLD_HEIGHT x CHUNK_SIZE
  meshes: THREE.Mesh[];
  dirty: boolean;
}

export class InfiniteWorld {
  chunks: Map<string, ChunkData> = new Map();
  terrainNoise: PerlinNoise;
  treeNoise: PerlinNoise;
  caveNoise: PerlinNoise;
  seed: number;

  constructor(seed?: number) {
    this.seed = seed ?? Math.floor(Math.random() * 100000);
    this.terrainNoise = new PerlinNoise(this.seed);
    this.treeNoise = new PerlinNoise(this.seed + 1000);
    this.caveNoise = new PerlinNoise(this.seed + 2000);
  }

  static chunkKey(cx: number, cz: number): string {
    return `${cx},${cz}`;
  }

  getTerrainHeight(worldX: number, worldZ: number): number {
    const nx = worldX / 100;
    const nz = worldZ / 100;
    
    // Large scale hills
    const large = this.terrainNoise.octaveNoise(nx * 0.5, nz * 0.5, 4, 0.5) * 20;
    // Medium detail
    const medium = this.terrainNoise.octaveNoise(nx * 2, nz * 2, 3, 0.4) * 8;
    // Small detail
    const small = this.terrainNoise.octaveNoise(nx * 5, nz * 5, 2, 0.3) * 3;
    
    const height = Math.floor(30 + large + medium + small);
    return Math.max(1, Math.min(WORLD_HEIGHT - 10, height));
  }

  generateChunk(cx: number, cz: number): ChunkData {
    const key = InfiniteWorld.chunkKey(cx, cz);
    if (this.chunks.has(key)) return this.chunks.get(key)!;

    const blocks: (BlockType | null)[][][] = [];
    
    // Initialize
    for (let x = 0; x < CHUNK_SIZE; x++) {
      blocks[x] = [];
      for (let y = 0; y < WORLD_HEIGHT; y++) {
        blocks[x][y] = [];
        for (let z = 0; z < CHUNK_SIZE; z++) {
          blocks[x][y][z] = null;
        }
      }
    }

    const worldOffsetX = cx * CHUNK_SIZE;
    const worldOffsetZ = cz * CHUNK_SIZE;

    // Generate terrain
    for (let lx = 0; lx < CHUNK_SIZE; lx++) {
      for (let lz = 0; lz < CHUNK_SIZE; lz++) {
        const wx = worldOffsetX + lx;
        const wz = worldOffsetZ + lz;
        const height = this.getTerrainHeight(wx, wz);

        for (let y = 0; y < height; y++) {
          if (y === 0) {
            blocks[lx][y][lz] = 'stone'; // bedrock-like
          } else if (y < height - 4) {
            blocks[lx][y][lz] = 'stone';
            // Coal ore
            if (seededRandom(wx + y * 997, wz, this.seed + 500) < 0.015 && y < height - 8) {
              blocks[lx][y][lz] = 'coal';
            }
            // Simple caves
            const caveVal = this.caveNoise.octaveNoise(wx / 20, (y + wz * 0.3) / 20, 3, 0.5);
            const caveVal2 = this.caveNoise.octaveNoise((wx + 1000) / 15, (y * 0.5 + wz) / 15, 3, 0.5);
            if (caveVal > 0.35 && caveVal2 > 0.35 && y > 1 && y < height - 5) {
              blocks[lx][y][lz] = null;
            }
          } else if (y < height - 1) {
            blocks[lx][y][lz] = height <= WATER_LEVEL + 2 ? 'sand' : 'dirt';
          } else {
            blocks[lx][y][lz] = height <= WATER_LEVEL + 2 ? 'sand' : 'grass';
          }
        }

        // Water fill
        for (let y = height; y < WATER_LEVEL; y++) {
          if (blocks[lx][y][lz] === null) {
            blocks[lx][y][lz] = 'water';
          }
        }
      }
    }

    // Trees - use seeded random so they're deterministic
    for (let lx = 2; lx < CHUNK_SIZE - 2; lx++) {
      for (let lz = 2; lz < CHUNK_SIZE - 2; lz++) {
        const wx = worldOffsetX + lx;
        const wz = worldOffsetZ + lz;
        const height = this.getTerrainHeight(wx, wz);

        if (height > WATER_LEVEL + 2 && height < WORLD_HEIGHT - 10) {
          const treeRand = seededRandom(wx, wz, this.seed + 100);
          const treeCluster = this.treeNoise.noise(wx * 0.1, wz * 0.1);
          if (treeRand < 0.012 && treeCluster > -0.1) {
            const treeHeight = 4 + Math.floor(seededRandom(wx, wz, this.seed + 200) * 3);
            // Trunk
            for (let ty = 0; ty < treeHeight; ty++) {
              const y = height + ty;
              if (y < WORLD_HEIGHT) {
                blocks[lx][y][lz] = 'wood';
              }
            }
            // Leaves
            const leafBase = height + treeHeight - 2;
            const leafTop = height + treeHeight + 1;
            for (let dlx = -2; dlx <= 2; dlx++) {
              for (let dlz = -2; dlz <= 2; dlz++) {
                for (let ly = leafBase; ly <= leafTop; ly++) {
                  const blx = lx + dlx;
                  const blz = lz + dlz;
                  if (blx >= 0 && blx < CHUNK_SIZE && blz >= 0 && blz < CHUNK_SIZE && ly < WORLD_HEIGHT) {
                    if (Math.abs(dlx) === 2 && Math.abs(dlz) === 2 && seededRandom(wx + dlx, wz + dlz + ly, this.seed + 300) < 0.5) continue;
                    if (ly === leafTop && (Math.abs(dlx) > 1 || Math.abs(dlz) > 1)) continue;
                    if (blocks[blx][ly][blz] === null) {
                      blocks[blx][ly][blz] = 'leaves';
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    const chunk: ChunkData = {
      cx, cz,
      blocks,
      meshes: [],
      dirty: true,
    };
    this.chunks.set(key, chunk);
    return chunk;
  }

  getBlock(wx: number, wy: number, wz: number): BlockType | null {
    if (wy < 0 || wy >= WORLD_HEIGHT) return null;
    const cx = Math.floor(wx / CHUNK_SIZE);
    const cz = Math.floor(wz / CHUNK_SIZE);
    const lx = ((wx % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    const lz = ((wz % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    const key = InfiniteWorld.chunkKey(cx, cz);
    const chunk = this.chunks.get(key);
    if (!chunk) return null;
    return chunk.blocks[lx][wy][lz];
  }

  setBlock(wx: number, wy: number, wz: number, block: BlockType | null): boolean {
    if (wy < 0 || wy >= WORLD_HEIGHT) return false;
    const cx = Math.floor(wx / CHUNK_SIZE);
    const cz = Math.floor(wz / CHUNK_SIZE);
    const lx = ((wx % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    const lz = ((wz % CHUNK_SIZE) + CHUNK_SIZE) % CHUNK_SIZE;
    const key = InfiniteWorld.chunkKey(cx, cz);
    const chunk = this.chunks.get(key);
    if (!chunk) return false;
    chunk.blocks[lx][wy][lz] = block;
    chunk.dirty = true;
    
    // Mark neighboring chunks dirty if on edge
    if (lx === 0) {
      const neighbor = this.chunks.get(InfiniteWorld.chunkKey(cx - 1, cz));
      if (neighbor) neighbor.dirty = true;
    }
    if (lx === CHUNK_SIZE - 1) {
      const neighbor = this.chunks.get(InfiniteWorld.chunkKey(cx + 1, cz));
      if (neighbor) neighbor.dirty = true;
    }
    if (lz === 0) {
      const neighbor = this.chunks.get(InfiniteWorld.chunkKey(cx, cz - 1));
      if (neighbor) neighbor.dirty = true;
    }
    if (lz === CHUNK_SIZE - 1) {
      const neighbor = this.chunks.get(InfiniteWorld.chunkKey(cx, cz + 1));
      if (neighbor) neighbor.dirty = true;
    }
    
    return true;
  }

  getSpawnPosition(): THREE.Vector3 {
    // Spawn at world origin, find ground
    const wx = 0;
    const wz = 0;
    const height = this.getTerrainHeight(wx, wz);
    return new THREE.Vector3(wx + 0.5, Math.max(height, WATER_LEVEL) + 2, wz + 0.5);
  }
}

// Build mesh for a single chunk
export function buildChunkMesh(
  world: InfiniteWorld,
  chunk: ChunkData,
  scene: THREE.Scene,
  materials: Record<BlockType, THREE.Material[]>
): THREE.Mesh[] {
  // Remove old meshes
  for (const m of chunk.meshes) {
    scene.remove(m);
    if (m instanceof THREE.InstancedMesh) {
      m.geometry.dispose();
    }
    m.geometry.dispose();
  }

  const meshes: THREE.Mesh[] = [];
  const blockGeo = new THREE.BoxGeometry(1, 1, 1);
  
  const blockTypes: BlockType[] = ['grass', 'dirt', 'stone', 'wood', 'leaves', 'sand', 'water', 'coal', 'planks'];
  const matrices: Record<string, THREE.Matrix4[]> = {};
  
  for (const bt of blockTypes) {
    matrices[bt] = [];
  }

  const worldOffsetX = chunk.cx * CHUNK_SIZE;
  const worldOffsetZ = chunk.cz * CHUNK_SIZE;

  for (let lx = 0; lx < CHUNK_SIZE; lx++) {
    for (let y = 0; y < WORLD_HEIGHT; y++) {
      for (let lz = 0; lz < CHUNK_SIZE; lz++) {
        const block = chunk.blocks[lx][y][lz];
        if (block === null) continue;

        const wx = worldOffsetX + lx;
        const wz = worldOffsetZ + lz;

        // Check all 6 neighbors for visibility
        const neighbors = [
          world.getBlock(wx + 1, y, wz),
          world.getBlock(wx - 1, y, wz),
          world.getBlock(wx, y + 1, wz),
          world.getBlock(wx, y - 1, wz),
          world.getBlock(wx, y, wz + 1),
          world.getBlock(wx, y, wz - 1),
        ];

        let hasExposedFace = false;
        for (const n of neighbors) {
          if (n === null || (n === 'water' && block !== 'water') || (n === 'leaves' && block !== 'leaves')) {
            hasExposedFace = true;
            break;
          }
        }
        // Also exposed at world height boundaries
        if (y === 0 || y === WORLD_HEIGHT - 1) hasExposedFace = true;

        if (hasExposedFace) {
          const mat = new THREE.Matrix4();
          mat.setPosition(wx, y, wz);
          matrices[block].push(mat);
        }
      }
    }
  }

  for (const bt of blockTypes) {
    if (matrices[bt].length === 0) continue;
    const mesh = new THREE.InstancedMesh(blockGeo, materials[bt], matrices[bt].length);
    for (let i = 0; i < matrices[bt].length; i++) {
      mesh.setMatrixAt(i, matrices[bt][i]);
    }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.userData.blockType = bt;
    mesh.userData.chunkKey = InfiniteWorld.chunkKey(chunk.cx, chunk.cz);
    mesh.frustumCulled = true;
    scene.add(mesh);
    meshes.push(mesh);
  }

  chunk.meshes = meshes;
  chunk.dirty = false;
  return meshes;
}
