import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { BlockType, createBlockMaterials } from './textures';
import { InfiniteWorld, buildChunkMesh, CHUNK_SIZE, WORLD_HEIGHT, RENDER_DISTANCE, UNLOAD_DISTANCE } from './world';

const BLOCK_TYPES: BlockType[] = ['grass', 'dirt', 'stone', 'wood', 'leaves', 'sand', 'planks', 'coal'];
const BLOCK_LABELS: Record<BlockType, string> = {
  grass: 'Herbe',
  dirt: 'Terre',
  stone: 'Pierre',
  wood: 'Bois',
  leaves: 'Feuilles',
  sand: 'Sable',
  water: 'Eau',
  coal: 'Charbon',
  planks: 'Planches',
};
const BLOCK_COLORS: Record<BlockType, string> = {
  grass: '#4C9900',
  dirt: '#866043',
  stone: '#808080',
  wood: '#8C5A32',
  leaves: '#2D8C0A',
  sand: '#D2C8A0',
  water: '#1E64C8',
  coal: '#333333',
  planks: '#B48C50',
};

interface GameState {
  camera: THREE.PerspectiveCamera;
  scene: THREE.Scene;
  renderer: THREE.WebGLRenderer;
  world: InfiniteWorld;
  materials: Record<BlockType, THREE.Material[]>;
  velocity: THREE.Vector3;
  onGround: boolean;
  keys: Set<string>;
  euler: THREE.Euler;
  raycaster: THREE.Raycaster;
  highlightMesh: THREE.Mesh;
  selectedBlock: number;
  lastChunkX: number;
  lastChunkZ: number;
}

function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLocked, setIsLocked] = useState(false);
  const [selectedBlock, setSelectedBlock] = useState(0);
  const [showInstructions, setShowInstructions] = useState(true);
  const [loading, setLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [fps, setFps] = useState(0);
  const [playerPos, setPlayerPos] = useState({ x: 0, y: 0, z: 0 });

  const gameStateRef = useRef<GameState | null>(null);

  // Load/unload chunks around player
  const updateChunks = useCallback((gs: GameState, force: boolean = false) => {
    const playerChunkX = Math.floor(gs.camera.position.x / CHUNK_SIZE);
    const playerChunkZ = Math.floor(gs.camera.position.z / CHUNK_SIZE);

    if (!force && playerChunkX === gs.lastChunkX && playerChunkZ === gs.lastChunkZ) return;

    gs.lastChunkX = playerChunkX;
    gs.lastChunkZ = playerChunkZ;

    // Generate and build chunks in render distance
    const chunksToLoad: { cx: number; cz: number; dist: number }[] = [];
    for (let dx = -RENDER_DISTANCE; dx <= RENDER_DISTANCE; dx++) {
      for (let dz = -RENDER_DISTANCE; dz <= RENDER_DISTANCE; dz++) {
        const dist = Math.sqrt(dx * dx + dz * dz);
        if (dist <= RENDER_DISTANCE) {
          chunksToLoad.push({ cx: playerChunkX + dx, cz: playerChunkZ + dz, dist });
        }
      }
    }
    // Sort by distance - load closest first
    chunksToLoad.sort((a, b) => a.dist - b.dist);

    for (const { cx, cz } of chunksToLoad) {
      const key = InfiniteWorld.chunkKey(cx, cz);
      let chunk = gs.world.chunks.get(key);
      if (!chunk) {
        chunk = gs.world.generateChunk(cx, cz);
      }
      if (chunk.dirty) {
        buildChunkMesh(gs.world, chunk, gs.scene, gs.materials);
      }
    }

    // Unload far chunks
    const keysToRemove: string[] = [];
    for (const [key, chunk] of gs.world.chunks) {
      const dx = chunk.cx - playerChunkX;
      const dz = chunk.cz - playerChunkZ;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist > UNLOAD_DISTANCE) {
        // Remove meshes
        for (const m of chunk.meshes) {
          gs.scene.remove(m);
          if (m instanceof THREE.InstancedMesh) {
            m.dispose();
          }
        }
        keysToRemove.push(key);
      }
    }
    for (const key of keysToRemove) {
      gs.world.chunks.delete(key);
    }
  }, []);

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87CEEB);
    scene.fog = new THREE.FogExp2(0x87CEEB, 0.012);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 200);

    const renderer = new THREE.WebGLRenderer({ antialias: false });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    containerRef.current.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(50, 100, 50);
    scene.add(directionalLight);

    const hemiLight = new THREE.HemisphereLight(0x87CEEB, 0x556B2F, 0.3);
    scene.add(hemiLight);

    // Materials
    const materials = createBlockMaterials();

    // Generate world
    const world = new InfiniteWorld();

    // Spawn position
    const spawnPos = world.getSpawnPosition();
    
    // Generate spawn chunk first
    const spawnCX = Math.floor(spawnPos.x / CHUNK_SIZE);
    const spawnCZ = Math.floor(spawnPos.z / CHUNK_SIZE);
    
    // Pre-generate nearby chunks
    let totalToLoad = 0;
    let loaded = 0;
    const initialChunks: { cx: number; cz: number }[] = [];
    for (let dx = -RENDER_DISTANCE; dx <= RENDER_DISTANCE; dx++) {
      for (let dz = -RENDER_DISTANCE; dz <= RENDER_DISTANCE; dz++) {
        if (Math.sqrt(dx * dx + dz * dz) <= RENDER_DISTANCE) {
          initialChunks.push({ cx: spawnCX + dx, cz: spawnCZ + dz });
          totalToLoad++;
        }
      }
    }

    // Load chunks async to show progress
    const loadChunksAsync = async () => {
      for (const { cx, cz } of initialChunks) {
        const chunk = world.generateChunk(cx, cz);
        buildChunkMesh(world, chunk, scene, materials);
        loaded++;
        setLoadingProgress(Math.floor((loaded / totalToLoad) * 100));
        // Let UI update
        if (loaded % 5 === 0) {
          await new Promise(r => setTimeout(r, 0));
        }
      }

      // Re-calculate spawn height from actual generated terrain
      const actualSpawn = world.getSpawnPosition();
      camera.position.copy(actualSpawn);

      setLoading(false);
    };

    loadChunksAsync();

    // Highlight mesh
    const highlightGeo = new THREE.BoxGeometry(1.005, 1.005, 1.005);
    const highlightMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.15,
    });
    const highlightMesh = new THREE.Mesh(highlightGeo, highlightMat);
    highlightMesh.visible = false;
    scene.add(highlightMesh);

    // Wireframe outline
    const wireGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.01, 1.01, 1.01));
    const wireMat = new THREE.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.8 });
    const wireframe = new THREE.LineSegments(wireGeo, wireMat);
    highlightMesh.add(wireframe);

    const gameState: GameState = {
      camera,
      scene,
      renderer,
      world,
      materials,
      velocity: new THREE.Vector3(),
      onGround: false,
      keys: new Set<string>(),
      euler: new THREE.Euler(0, 0, 0, 'YXZ'),
      raycaster: new THREE.Raycaster(),
      highlightMesh,
      selectedBlock: 0,
      lastChunkX: -99999,
      lastChunkZ: -99999,
    };
    gameStateRef.current = gameState;
    gameState.raycaster.far = 7;

    // --- Event Handlers ---
    const onMouseMove = (e: MouseEvent) => {
      if (!document.pointerLockElement) return;
      const sensitivity = 0.002;
      gameState.euler.setFromQuaternion(camera.quaternion);
      gameState.euler.y -= e.movementX * sensitivity;
      gameState.euler.x -= e.movementY * sensitivity;
      gameState.euler.x = Math.max(-Math.PI / 2 + 0.01, Math.min(Math.PI / 2 - 0.01, gameState.euler.x));
      camera.quaternion.setFromEuler(gameState.euler);
    };

    const onKeyDown = (e: KeyboardEvent) => {
      gameState.keys.add(e.code);
      if (e.code >= 'Digit1' && e.code <= 'Digit8') {
        const idx = parseInt(e.code.replace('Digit', '')) - 1;
        gameState.selectedBlock = idx;
        setSelectedBlock(idx);
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      gameState.keys.delete(e.code);
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const dir = e.deltaY > 0 ? 1 : -1;
      gameState.selectedBlock = ((gameState.selectedBlock + dir) % BLOCK_TYPES.length + BLOCK_TYPES.length) % BLOCK_TYPES.length;
      setSelectedBlock(gameState.selectedBlock);
    };

    // Raycast to find targeted block
    const getTargetBlock = (): { pos: THREE.Vector3; normal: THREE.Vector3; worldPos: THREE.Vector3 } | null => {
      gameState.raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
      
      // Collect all chunk meshes
      const allMeshes: THREE.Mesh[] = [];
      for (const [, chunk] of gameState.world.chunks) {
        allMeshes.push(...chunk.meshes);
      }
      
      const intersects = gameState.raycaster.intersectObjects(allMeshes);
      if (intersects.length === 0) return null;

      const hit = intersects[0];
      if (!hit.face || hit.instanceId === undefined) return null;

      const mesh = hit.object as THREE.InstancedMesh;
      const matrix = new THREE.Matrix4();
      mesh.getMatrixAt(hit.instanceId, matrix);
      const pos = new THREE.Vector3();
      pos.setFromMatrixPosition(matrix);

      // Get face normal in world space
      const normal = hit.face.normal.clone();
      const normalMatrix = new THREE.Matrix3().getNormalMatrix(mesh.matrixWorld);
      normal.applyMatrix3(normalMatrix).normalize();
      normal.x = Math.round(normal.x);
      normal.y = Math.round(normal.y);
      normal.z = Math.round(normal.z);

      return {
        pos: new THREE.Vector3(Math.round(pos.x), Math.round(pos.y), Math.round(pos.z)),
        normal,
        worldPos: pos,
      };
    };

    const onMouseDown = (e: MouseEvent) => {
      if (!document.pointerLockElement) {
        renderer.domElement.requestPointerLock();
        return;
      }

      const target = getTargetBlock();
      if (!target) return;

      if (e.button === 0) {
        // Break block
        const bx = Math.round(target.pos.x);
        const by = Math.round(target.pos.y);
        const bz = Math.round(target.pos.z);
        const block = gameState.world.getBlock(bx, by, bz);
        if (block && block !== 'water') {
          gameState.world.setBlock(bx, by, bz, null);
          // Rebuild dirty chunks
          rebuildDirtyChunks();
        }
      } else if (e.button === 2) {
        // Place block
        const placePos = target.pos.clone().add(target.normal);
        const bx = Math.round(placePos.x);
        const by = Math.round(placePos.y);
        const bz = Math.round(placePos.z);
        
        if (by >= 0 && by < WORLD_HEIGHT) {
          const existing = gameState.world.getBlock(bx, by, bz);
          if (!existing) {
            // Don't place where player is standing (check player bounding box)
            const px = Math.floor(camera.position.x);
            const py1 = Math.floor(camera.position.y - 0.3); // head area
            const py2 = Math.floor(camera.position.y - 1.0); // body
            const py3 = Math.floor(camera.position.y - 1.6); // feet
            const pz = Math.floor(camera.position.z);
            const isPlayerBlock = bx === px && bz === pz && (by === py1 || by === py2 || by === py3);
            if (!isPlayerBlock) {
              gameState.world.setBlock(bx, by, bz, BLOCK_TYPES[gameState.selectedBlock]);
              rebuildDirtyChunks();
            }
          }
        }
      }
    };

    const rebuildDirtyChunks = () => {
      for (const [, chunk] of gameState.world.chunks) {
        if (chunk.dirty) {
          buildChunkMesh(gameState.world, chunk, gameState.scene, gameState.materials);
        }
      }
    };

    const onContextMenu = (e: Event) => e.preventDefault();

    const onPointerLockChange = () => {
      const locked = !!document.pointerLockElement;
      setIsLocked(locked);
      setShowInstructions(!locked);
    };

    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);
    document.addEventListener('mousedown', onMouseDown);
    document.addEventListener('contextmenu', onContextMenu);
    document.addEventListener('pointerlockchange', onPointerLockChange);
    renderer.domElement.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('resize', onResize);

    // --- Collision Detection ---
    const PLAYER_WIDTH = 0.3;
    const PLAYER_HEIGHT = 1.62; // eye height
    const PLAYER_TOTAL_HEIGHT = 1.8;

    const isSolid = (wx: number, wy: number, wz: number): boolean => {
      const block = gameState.world.getBlock(Math.floor(wx), Math.floor(wy), Math.floor(wz));
      return block !== null && block !== 'water';
    };

    const checkCollisionAt = (px: number, py: number, pz: number): boolean => {
      // py is eye level. Feet are at py - PLAYER_HEIGHT
      const feetY = py - PLAYER_HEIGHT;
      const headY = feetY + PLAYER_TOTAL_HEIGHT;
      
      // Check multiple points around the player hitbox
      const offsets = [-PLAYER_WIDTH, PLAYER_WIDTH];
      for (const ox of offsets) {
        for (const oz of offsets) {
          // Check feet, knees, body, head
          for (let checkY = feetY; checkY <= headY; checkY += 0.5) {
            if (isSolid(px + ox, checkY, pz + oz)) {
              return true;
            }
          }
          // Always check head exactly
          if (isSolid(px + ox, headY, pz + oz)) return true;
        }
      }
      return false;
    };

    // --- Game Loop ---
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTimer = 0;
    let animId: number;
    let chunkUpdateTimer = 0;
    let posUpdateTimer = 0;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const now = performance.now();
      const rawDelta = (now - lastTime) / 1000;
      const delta = Math.min(rawDelta, 0.05); // Cap delta to prevent tunneling
      lastTime = now;

      // FPS counter
      frameCount++;
      fpsTimer += rawDelta;
      if (fpsTimer >= 1) {
        setFps(frameCount);
        frameCount = 0;
        fpsTimer = 0;
      }

      if (document.pointerLockElement) {
        // Movement
        const speed = gameState.keys.has('ShiftLeft') ? 8 : 5;
        const direction = new THREE.Vector3();
        const forward = new THREE.Vector3();
        camera.getWorldDirection(forward);
        forward.y = 0;
        forward.normalize();
        const right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();

        if (gameState.keys.has('KeyW') || gameState.keys.has('ArrowUp')) direction.add(forward);
        if (gameState.keys.has('KeyS') || gameState.keys.has('ArrowDown')) direction.sub(forward);
        if (gameState.keys.has('KeyA') || gameState.keys.has('ArrowLeft')) direction.sub(right);
        if (gameState.keys.has('KeyD') || gameState.keys.has('ArrowRight')) direction.add(right);

        if (direction.lengthSq() > 0) direction.normalize();

        // Apply horizontal movement with collision (X and Z separately)
        const moveX = direction.x * speed * delta;
        const moveZ = direction.z * speed * delta;

        // Try X
        if (!checkCollisionAt(camera.position.x + moveX, camera.position.y, camera.position.z)) {
          camera.position.x += moveX;
        }
        // Try Z
        if (!checkCollisionAt(camera.position.x, camera.position.y, camera.position.z + moveZ)) {
          camera.position.z += moveZ;
        }

        // Gravity & jumping
        if (gameState.keys.has('Space') && gameState.onGround) {
          gameState.velocity.y = 7.5;
          gameState.onGround = false;
        }

        gameState.velocity.y -= 22 * delta; // gravity
        gameState.velocity.y = Math.max(gameState.velocity.y, -40); // terminal velocity

        const moveY = gameState.velocity.y * delta;
        const newY = camera.position.y + moveY;

        if (checkCollisionAt(camera.position.x, newY, camera.position.z)) {
          if (gameState.velocity.y < 0) {
            // Landing - snap to ground
            gameState.onGround = true;
            // Find exact ground level by stepping down until we hit something
            const step = 0.05;
            let totalDrop = 0;
            while (totalDrop < 2 && !checkCollisionAt(camera.position.x, camera.position.y - totalDrop - step, camera.position.z)) {
              totalDrop += step;
            }
            if (totalDrop > 0) {
              camera.position.y -= totalDrop;
            }
          }
          gameState.velocity.y = 0;
        } else {
          camera.position.y = newY;
          gameState.onGround = false;
        }

        // Respawn if fell into void
        if (camera.position.y < -20) {
          const sp = gameState.world.getSpawnPosition();
          camera.position.copy(sp);
          gameState.velocity.set(0, 0, 0);
        }

        // Update highlight
        const target = getTargetBlock();
        if (target) {
          highlightMesh.visible = true;
          highlightMesh.position.copy(target.pos);
        } else {
          highlightMesh.visible = false;
        }

        // Update chunks periodically
        chunkUpdateTimer += delta;
        if (chunkUpdateTimer > 0.5) {
          chunkUpdateTimer = 0;
          updateChunks(gameState);
        }

        // Update position display
        posUpdateTimer += delta;
        if (posUpdateTimer > 0.25) {
          posUpdateTimer = 0;
          setPlayerPos({
            x: Math.floor(camera.position.x),
            y: Math.floor(camera.position.y),
            z: Math.floor(camera.position.z),
          });
        }
      }

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animId);
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('keyup', onKeyUp);
      document.removeEventListener('mousedown', onMouseDown);
      document.removeEventListener('contextmenu', onContextMenu);
      document.removeEventListener('pointerlockchange', onPointerLockChange);
      renderer.domElement.removeEventListener('wheel', onWheel);
      window.removeEventListener('resize', onResize);
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [updateChunks]);

  return (
    <div className="relative w-full h-full">
      <div ref={containerRef} className="w-full h-full" />

      {/* Crosshair */}
      {isLocked && (
        <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-10">
          <div className="relative w-8 h-8">
            <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white -translate-y-1/2 opacity-80" style={{ mixBlendMode: 'difference' }} />
            <div className="absolute left-1/2 top-0 h-full w-0.5 bg-white -translate-x-1/2 opacity-80" style={{ mixBlendMode: 'difference' }} />
          </div>
        </div>
      )}

      {/* Debug Info */}
      {isLocked && (
        <div className="fixed top-2 left-2 text-white text-xs font-mono bg-black/60 px-2 py-1.5 rounded z-10 space-y-0.5">
          <div>{fps} FPS</div>
          <div>XYZ: {playerPos.x} / {playerPos.y} / {playerPos.z}</div>
          <div>Chunks: {gameStateRef.current?.world.chunks.size ?? 0}</div>
        </div>
      )}

      {/* Hotbar */}
      {isLocked && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 flex gap-0.5 z-10 bg-black/50 p-1 rounded-lg">
          {BLOCK_TYPES.map((bt, i) => (
            <div
              key={bt}
              className={`w-11 h-11 rounded flex flex-col items-center justify-center transition-all ${
                i === selectedBlock
                  ? 'border-2 border-white scale-110 bg-white/20'
                  : 'border border-gray-600/50 bg-black/30'
              }`}
            >
              <div
                className="w-6 h-6 rounded-sm"
                style={{ backgroundColor: BLOCK_COLORS[bt] }}
              />
              <span className="text-white text-[7px] mt-0.5 font-mono opacity-70">{i + 1}</span>
            </div>
          ))}
        </div>
      )}

      {/* Block name */}
      {isLocked && (
        <div className="fixed bottom-[72px] left-1/2 -translate-x-1/2 text-white text-xs font-mono bg-black/50 px-3 py-1 rounded z-10">
          {BLOCK_LABELS[BLOCK_TYPES[selectedBlock]]}
        </div>
      )}

      {/* Instructions */}
      {showInstructions && !loading && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/75 z-20 backdrop-blur-sm">
          <div className="bg-gray-900/95 p-8 rounded-xl max-w-lg w-full mx-4 text-center border border-gray-700 shadow-2xl">
            <h1
              className="text-4xl font-bold text-green-400 mb-1 tracking-wider"
              style={{ fontFamily: 'monospace', textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}
            >
              ⛏ MINECRAFT WEB
            </h1>
            <p className="text-gray-400 mb-6 text-sm">Monde infini — Explorez sans limites !</p>

            <div className="text-left text-gray-300 space-y-1.5 mb-6 text-sm">
              <div className="grid grid-cols-2 gap-1.5">
                <div className="bg-gray-800/80 p-2 rounded flex items-center gap-2">
                  <span className="text-yellow-400 font-bold text-xs bg-yellow-400/10 px-1.5 py-0.5 rounded">ZQSD</span>
                  <span>Se déplacer</span>
                </div>
                <div className="bg-gray-800/80 p-2 rounded flex items-center gap-2">
                  <span className="text-yellow-400 font-bold text-xs bg-yellow-400/10 px-1.5 py-0.5 rounded">Souris</span>
                  <span>Regarder</span>
                </div>
                <div className="bg-gray-800/80 p-2 rounded flex items-center gap-2">
                  <span className="text-yellow-400 font-bold text-xs bg-yellow-400/10 px-1.5 py-0.5 rounded">Espace</span>
                  <span>Sauter</span>
                </div>
                <div className="bg-gray-800/80 p-2 rounded flex items-center gap-2">
                  <span className="text-yellow-400 font-bold text-xs bg-yellow-400/10 px-1.5 py-0.5 rounded">Shift</span>
                  <span>Sprinter</span>
                </div>
                <div className="bg-gray-800/80 p-2 rounded flex items-center gap-2">
                  <span className="text-yellow-400 font-bold text-xs bg-yellow-400/10 px-1.5 py-0.5 rounded">Clic G</span>
                  <span>Casser un bloc</span>
                </div>
                <div className="bg-gray-800/80 p-2 rounded flex items-center gap-2">
                  <span className="text-yellow-400 font-bold text-xs bg-yellow-400/10 px-1.5 py-0.5 rounded">Clic D</span>
                  <span>Placer un bloc</span>
                </div>
                <div className="bg-gray-800/80 p-2 rounded flex items-center gap-2 col-span-2">
                  <span className="text-yellow-400 font-bold text-xs bg-yellow-400/10 px-1.5 py-0.5 rounded">1-8 / Molette</span>
                  <span>Sélectionner un bloc</span>
                </div>
              </div>
            </div>

            <button
              className="px-8 py-3 bg-green-600 hover:bg-green-500 text-white rounded-lg font-bold text-lg transition-colors shadow-lg hover:shadow-green-500/30 cursor-pointer active:scale-95"
              onClick={() => {
                containerRef.current?.querySelector('canvas')?.requestPointerLock();
              }}
            >
              🎮 Jouer !
            </button>
            <p className="text-gray-500 text-xs mt-3">Cliquez pour capturer la souris · Échap pour la libérer</p>
          </div>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="fixed inset-0 flex items-center justify-center bg-black z-30">
          <div className="text-center">
            <div className="text-5xl mb-4">⛏</div>
            <h2 className="text-2xl text-green-400 font-mono mb-3">Génération du monde...</h2>
            <div className="w-64 h-3 bg-gray-800 rounded-full mx-auto overflow-hidden border border-gray-700">
              <div
                className="h-full bg-gradient-to-r from-green-600 to-green-400 rounded-full transition-all duration-200"
                style={{ width: `${loadingProgress}%` }}
              />
            </div>
            <p className="text-gray-500 text-sm mt-2 font-mono">{loadingProgress}%</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
